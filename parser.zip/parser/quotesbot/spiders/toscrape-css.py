# -*- coding: utf-8 -*-
import scrapy


class ToScrapeCSSSpider(scrapy.Spider):
    name = "toscrape-css"
    def link_gen():
        with open("links.txt", "r") as file:
            links = file.readlines()[200::]
        for i in links:
            yield i
    links = link_gen()
    start_urls = [
        next(links),
    ]
   # d = []
    def parse(self, response):
        output = {
            "title":response.xpath("//p[@class='bigtext']/text()").extract_first(),
            "journal": response.xpath("//a[@title='Содержание выпусков этого журнала']/text()").extract_first(),
            "volume": None,
            "issue":response.xpath("//a[@title='Содержание выпуска']/text()").extract_first(),
            "pages":response.xpath("//div[contains(text(), 'Страницы')]/font/text()").extract_first(),
            #"year":response.xpath("//td/span[@style='margin-left:20px;']/../font/text()").extract()[2],
            "year": response.selector.re_first("19\d\d|20[0-2]\d"),
            "author": response.xpath("//div/b/font[@color='#00008f']/text() | //div/span/b/font[@color='#00008f']/text()").extract(),
            "eissn":None,
            "pissn": None,
            "affiliations": [],
            "abstract":response.xpath("//div[@id='abstract1']/p/text()").extract_first(),
            "references": []
            }
        if response.selector.re("[^e]ISSN"):
            output["pissn"] = response.selector.re("\d{4}-\d{4}")[0]
            if response.selector.re("eISSN"):
                output["eissn"] = response.selector.re("\d{4}-\d{4}")[1]
        elif response.selector.re("eISSN"):
            output["eissn"] = response.selector.re("\d{4}-\d{4}")[0]
        if response.selector.re('Том'):
            output['volume'] = response.xpath("//td[contains(., 'Том')]/font[@color='#00008f']/text")
        #self.d.append(output)
        yield output
        next_page_url = next(self.links)
        if next_page_url is not None:
            yield scrapy.Request(next_page_url, dont_filter=True,  callback=self.parse)

